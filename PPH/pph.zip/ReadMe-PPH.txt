Gerador dos Coefficientes a0, a1, ..., aN e b0, b1, ..., bN.


Entrada:  n - grau dos polin�mios.
	  n_inst - n�mero de inst�ncias a gerar com os par�metros acima

Formato do Arquivo:

O arquivo possui 3+n n�meros inteiros. Todos os separadores
s�o brancos exceto pelos CR e LF no final das linhas.

O primeiro inteiro cont�m  "n".  
Os n+1 inteiros seguintes correspondem aos coeficientes a0, a1, ..., aN.
Os n+1 inteiros restantes correspondem aos coeficientes b0, b1, ..., bN.

Se voc� preferir, pode copiar o gerador para o seu c�digo
e utiliz�lo sem gerar arquivos. Fa�a isso com aten��o.
